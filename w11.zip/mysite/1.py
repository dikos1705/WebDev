list= [2,3,4]
sum = 0
for i in range(len(list)):
    if (i%2==0):
        sum += list[i]
print(sum)